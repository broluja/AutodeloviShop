first column is gbg code
second column is availabilty 

